<?php require("includes/config.php");?>
<?php
if (isset($_SESSION['studentId'])) {
    header('Location: index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php require("includes/head.php");?>
</head>
<body>
    <?php require("includes/navbar.php");?>
    <div class="row">
        <div class="col-10 mx-auto">
            <div class="card card-signin my-5">
                <div class="card-body">
                    <h5 class="card-title text-center">Registration Form</h5>
                    <?php
                    if (isset($_GET['error'])) {
                        switch ($_GET['error']){
                            case 'accountcreated':
                                echo '<div class="alert alert-danger" role="alert">All Fields Must be Filled Out!</div>';
                                break;
                            case 'invalidemail':
                                echo '<div class="alert alert-danger" role="alert">You Must Enter a Valid Email!</div>';
                                break;
                            case 'passwordmatch':
                                echo '<div class="alert alert-danger" role="alert">Passwords do not Match!</div>';
                                break;
                            case 'uniqueemail':
                                echo '<div class="alert alert-danger" role="alert">A Student with that Email Already Exists!</div>';
                                break;
                        }
                    }
                    ?>
                    <form action="includes/signup.php" method="post">
                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" name="email" placeholder="Name@Email.com">
                            </div>
                            <div class="form-group col-md-4">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" name="password" placeholder="Password">
                            </div>
                            <div class="form-group col-md-4">
                                <label for="password">Confirm Password</label>
                                <input type="password" class="form-control" name="password-reenter" placeholder="Confirm Password">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <label for="firstName">First Name</label>
                                <input type="text" class="form-control" name="firstName" placeholder="First Name">
                            </div>
                            <div class="form-group col-md-4">
                                <label for="lastName">Last Name</label>
                                <input type="text" class="form-control" name="lastName" placeholder="Last Name">
                            </div>
                            <div class="form-group col-md-4">
                                <label for="phone">Phone Number</label>
                                <input type="tel" class="form-control" name="phone" placeholder="123-456-7890" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}">
                            </div>
                        </div>
                        <div class="text-center">
                            <br>
                            <button type="submit" name="submit-signup" class="btn btn-lg btn-primary text-uppercase">Sign up</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
<?php require("includes/scripts.php")?>
</html>