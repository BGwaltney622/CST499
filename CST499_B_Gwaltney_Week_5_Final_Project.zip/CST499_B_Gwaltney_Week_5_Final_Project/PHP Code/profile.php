<?php 
    require 'includes/config.php';
    require 'classes/student.php';
    require 'classes/course_registrations.php';
    require 'classes/course.php';

    if (!isset($_SESSION['studentId'])) {
        header('Location: login.php');
    }

    $student = Student::getStudent($_SESSION['studentId']);
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <?php require("includes/head.php");?>
    </head>

    <body>
        <?php require("includes/navbar.php");?>
        <hr>
        <div class="container">
            <div class="row">
                <div class="col-sm-3"></div>
                <div class="col-sm-9 text-center">
                    <h1><?php echo $student->getFirstName().' '.$student->getLastName(); ?></h1>
                    <?php
                    if (isset($_GET['error'])) {
                        switch ($_GET['error']){
                            case 'badfiletype':
                                echo '<div class="alert alert-danger" role="alert">File type not allowed, must be jpeg, jpg, or png</div>';
                                break;
                            case 'filetolarge':
                                echo '<div class="alert alert-danger" role="alert">File must not be larger than 4mb</div>';
                                break;
                            case 'unknownerror':
                                echo '<div class="alert alert-danger" role="alert">An unknown error has occured, please try again</div>';
                                break;
                            case 'emptyfields':
                                echo '<div class="alert alert-danger" role="alert">All fields must be completed</div>';
                                break;
                            case 'invalidemail':
                                    echo '<div class="alert alert-danger" role="alert">You must enter a valid email</div>';
                                break;
                        }
                    }
                    if (isset($_GET['success'])) {
                        switch ($_GET['success']){
                            case 'fileuploaded':
                                echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <strong>Your file has been uploaded!</strong>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>';
                                break;
                            case 'updated':
                                echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <strong>Profile Updated!</strong>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>';
                                break;
                            case 'waitlistremoved':
                                echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <strong>Removed from Waitlist!</strong>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>';
                                break;
                            case 'enrollmentremoved':
                                echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <strong>Removed from Course!</strong>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>';
                                break;
                        }
                    }
                    
                    ?>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-3">
                    <div>
                        <img src=<?php echo $student->getPicture() ?> class="avatar img-circle img-thumbnail" alt="avatar">
                        <form action="includes/filesubmit.php" method="post" enctype="multipart/form-data">
                            <h6>Upload a different photo...</h6>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" name="customFile" id="customFile">
                                <label class="custom-file-label" for="customFile">Choose file</label>
                            </div>
                            <button class="btn btn-md btn-primary mt-3" name="picture-submit"
                                type="submit">Upload</button>
                        </form>
                    </div>
                    </hr><br>
                </div>

                <div class="col-sm-9">
                    <div class="tab-content">
                        <div class="tab-pane active" id="home">
                            <hr>
                            <form class="form" action="includes/update.php" method="post" id="registrationForm">

                                <div class="form-group">
                                    <div class="col-xs-6">
                                        <label for="firstName">
                                            <h4>First name</h4>
                                        </label>
                                        <input type="text" class="form-control" name="firstName" id="firstName"
                                            value=<?php echo $student->getFirstName(); ?> disabled>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-xs-6">
                                        <label for="lastName">
                                            <h4>Last name</h4>
                                        </label>
                                        <input type="text" class="form-control" name="lastName" id="lastName"
                                            value=<?php echo $student->getLastName(); ?> disabled>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-xs-6">
                                        <label for="email">
                                            <h4>Email</h4>
                                        </label>
                                        <input type="email" class="form-control" name="email" id="email"
                                            value=<?php echo $student->getEmail(); ?> disabled>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-xs-6">
                                        <label for="phone">
                                            <h4>Phone</h4>
                                        </label>
                                        <input type="text" class="form-control" name="phone" id="phone"
                                            value=<?php echo $student->getPhone(); ?> pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" disabled >
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-lg-8">

                                        <br>
                                        <button class="btn btn-lg btn-primary" name="update" type="submit">Save</button>
                                        <button class="btn btn-lg btn-secondary ml-2" name="edit" type="button"
                                            onclick="editFields()">Edit</button>
                                    </div>
                                </div>
                            </form>
                            <hr>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-sm-3"></div>
                <div class="col-sm-9 text-center">
                    <h1>Enrolled Courses</h1>
                    <hr>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-3"></div>
                <div class="col-sm-9 grid-container">
                    <?php
                        $studentEnrollments = CourseRegistrations::getRegistrationsByStudent($_SESSION['studentId']);
                        if (count($studentEnrollments)<1) {
                            echo '<h3>No Enrollments</h3>';
                        }
                        foreach ($studentEnrollments as $course_array) {
                            $course = Course::getCourse($course_array['courseId']);
                            echo '<form action="includes/course_register.php?courseId='.$course->getCourseId().'" method="post">  
                                <div class="card">
                                <h5 class="card-header">'.$course->getCourseName().'</h5>
                                    <div class="card-body">
                                        <h5 class="card-title">'.$course->getCourseSemester().'</h5>
                                        <p class="card-text">'.$course->getCourseDescription().'</p>
                                        <p class="card-text">'.(intval($course->getMaxEnrollments()) - intval(CourseRegistrations::getRegistrationsByCourse($course->getCourseId())['COUNT(*)'])).' out of '.$course->getMaxEnrollments().' avalible</p>
                                        <button type="submit" name="Profile_Cancel_Registration" class="btn btn-danger">Cancel Registration</button>
                                    </div>
                                </div>
                            </form>';
                        }
                    ?>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-sm-3"></div>
                <div class="col-sm-9 text-center">
                    <h1>Waitlisted Courses</h1>
                    <hr>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-3"></div>
                <div class="col-sm-9 grid-container">
                    <?php
                        $studentWaitlist = CourseRegistrations::getWaitlistsByStudent($_SESSION['studentId']);
                        if (count($studentWaitlist)<1) {
                            echo '<h3>No Courses Waitlisted</h3>';
                        }
                        foreach ($studentWaitlist as $waitlist_array) {
                            $course = Course::getCourse($waitlist_array['courseId']);
                            echo '<form action="includes/course_register.php?courseId='.$course->getCourseId().'" method="post">  
                                <div class="card">
                                <h5 class="card-header">'.$course->getCourseName().'</h5>
                                    <div class="card-body">
                                        <h5 class="card-title">'.$course->getCourseSemester().'</h5>
                                        <p class="card-text">'.$course->getCourseDescription().'</p>
                                        <p class="card-text">'.(intval($course->getMaxEnrollments()) - intval(CourseRegistrations::getRegistrationsByCourse($course->getCourseId())['COUNT(*)'])).' out of '.$course->getMaxEnrollments().' avalible</p>
                                        <button type="submit" name="Profile_Cancel_Waitlist" class="btn btn-warning">Cancel Waitlist</button>
                                    </div>
                                </div>
                            </form>';
                        }
                    ?>
                </div>
            </div>
        </div>
    </body>
    <?php require("includes/scripts.php");?>

</html>