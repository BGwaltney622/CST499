<?php require 'includes/config.php';?>
<?php require_once 'classes/student.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php require 'includes/head.php';?>
</head>
<body>
    <?php require 'includes/navbar.php';?>
    <?php
        //Login message
        if (isset($_GET['success'])) {
            switch ($_GET['success']){
                case 'login':
                    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>You are now Logged In!</strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>';
                    break;
            }
        } ?>
    <div class="jumbotron">
        <div class="container">
            <img src="public\large_07044846-c03b-4ad8-8c0b-e391d56bbb66.jpg" alt="Self-Service Banner" class = "img-responsive" width="100%" height = "450em">
        </div>
    </div>
    <?php
    //Changes Home content is signed in or not
    if (isset($_SESSION['studentId'])) {
        echo '<div class="text-center">
                <h1 class="text-center"> Welcome '.$_SESSION['firstName'].', You Are Logged In! </h1><br>
                <button type="button" class="btn btn-lg btn-primary"> <a href="./profile.php" class="text-reset text-decoration-none">View Profile</a> </button>
              </div>';
    }else {
        echo '<div class="container">
                <div class="row">
                    <div class="col-md text-center">
                        <h4>Login</h4>
                        <p class="text-justify">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perferendis nemo nam error eveniet facere reiciendis excepturi pariatur, impedit ipsum corporis. Corporis culpa dicta quibusdam sequi iste esse ad, beatae deleniti quis earum tempora. Pariatur iusto at fugit! Ipsam, veritatis eum.</p>
                        <button type="button" class="btn btn-primary"> <a href="./login.php" class="text-reset text-decoration-none">Login</a> </button>
                    </div>
                    <div class="col-md text-center">
                        <h4>Register</h4>
                        <p class="text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis molestias aut eveniet ea laborum reiciendis nemo eius veritatis ipsum cum dignissimos, maiores rem, odio hic animi! Rem quas, voluptatibus doloribus maiores sunt reprehenderit cum aut corporis numquam officiis, inventore repellendus?</p>
                        <button type="button" class="btn btn-success"> <a href="./registration.php" class="text-reset text-decoration-none">Register</a> </button>
                    </div>
                </div>
            </div>';
    }
    ?>
</body>
<?php require 'includes/scripts.php'?>
</html>