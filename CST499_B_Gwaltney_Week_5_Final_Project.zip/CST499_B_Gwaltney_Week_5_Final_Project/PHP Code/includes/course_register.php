<?php
    require 'config.php';
    require '../classes/course.php';
    require '../classes/student.php';
    require '../classes/course_registrations.php';

    $course = Course::getCourse($_GET['courseId']);

    if (isset($_POST['Register'])) {
        $courseEnrollments = CourseRegistrations::getRegistrationsByCourse($course->getCourseId());
        $studentEnrollments = CourseRegistrations::getRegistrationsByStudent($_SESSION['studentId']);

        if (CourseRegistrations::validateEnrollment($course->getCourseId(), $_SESSION['studentId'], $studentEnrollments)) {
            header('Location: ../courses.php?error=enrolled');
            exit();
        } else if ($course->getMaxEnrollments()>=$courseEnrollments) {
            header('Location: ../courses.php?error=waitlist');
            exit();
        } else {
            CourseRegistrations::register($course->getCourseId(), $_SESSION['studentId']);
            header('Location: ../courses.php?success=enrolled');
            exit();
        }
    } else if (isset($_POST['Waitlist'])) {
        CourseRegistrations::waitlist($course->getCourseId(), $_SESSION['studentId']);
        header('Location: ../courses.php?success=waitlist');
        exit();
    } else if (isset($_POST['Cancel_Waitlist'])) {
        CourseRegistrations::removeWaitlist($course->getCourseId(), $_SESSION['studentId']);
        header('Location: ../courses.php?success=waitlistremoved');
        exit();
    } else if (isset($_POST['Profile_Cancel_Waitlist'])) {
        CourseRegistrations::removeWaitlist($course->getCourseId(), $_SESSION['studentId']);
        header('Location: ../profile.php?success=waitlistremoved');
        exit();
    } else if (isset($_POST['Cancel_Registration'])) {
        CourseRegistrations::cancelEnrollment($course->getCourseId(), $_SESSION['studentId']);
        header('Location: ../courses.php?success=enrollmentremoved');
        exit();
    } else if (isset($_POST['Profile_Cancel_Registration'])) {
        CourseRegistrations::cancelEnrollment($course->getCourseId(), $_SESSION['studentId']);
        header('Location: ../profile.php?success=enrollmentremoved');
        exit();
    } else if (isset($_POST['Remove_Course'])) {
        $course->deleteCourse();
        header('Location: ../courses.php?success=coursedelete');
        exit();
    } else {
        header("Location: ../index.php?");
        exit();
    }