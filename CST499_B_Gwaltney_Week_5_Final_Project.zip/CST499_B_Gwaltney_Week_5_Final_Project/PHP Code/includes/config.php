<?php

session_start();

//Sets data about the pages
switch ($_SERVER["SCRIPT_NAME"]) {
	case "/Assignment/contact.php":
		$CURRENT_PAGE = "ContactUs"; 
		$PAGE_TITLE = "Contact Us";
		break;
	case "/Assignment/login.php":
		$CURRENT_PAGE = "Login"; 
		$PAGE_TITLE = "Login";
		break;
	case "/Assignment/registration.php":
		$CURRENT_PAGE = "Registration"; 
		$PAGE_TITLE = "Registration";
		break;
	case "/Assignment/profile.php":
		$CURRENT_PAGE = "Profile"; 
		$PAGE_TITLE = "Welcome, ".$_SESSION['firstName'];
		break;
	case "/Assignment/courses.php":
		$CURRENT_PAGE = "Courses"; 
		$PAGE_TITLE = "Course Registration";
		break;
	case "/Assignment/addcourse.php":
		$CURRENT_PAGE = "AddCourse"; 
		$PAGE_TITLE = "Add Course";
		break;
	default:
		$CURRENT_PAGE = "Home";
		$PAGE_TITLE = "Employee Portal";
}
