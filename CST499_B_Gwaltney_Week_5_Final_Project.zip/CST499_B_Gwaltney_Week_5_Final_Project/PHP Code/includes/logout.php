<?php
if (!isset($_SESSION['studentId'])) {
    header('Location: ../login.php');
}
//Terminates the Users session
session_start();
$_SESSION = array();
session_destroy();
header('Location: ../index.php');