<?php

//Validates script was entered from submit button on login form
if (isset($_POST['sign-in'])) {

    require('../classes/student.php');

    //Sets Form Variables
    $email = $_POST['email'];
    $password = $_POST['password'];

    //Validates for fields and login infomration
    if (empty($email) || empty($password)) {
        header('Location: ../login.php?error=emptyfields');
        exit();
    } else {
        $validation = Student::validateLogin($email, $password);

        if ($validation === 'no student') {
            header('Location: ../login.php?error=nostudentfound');
            exit();
        } else if ($validation === 'wrong password') {
            header('Location: ../login.php?error=wrongpassword');
            exit();
        } else if ($validation === 'unknown error') {
            header('Location: ../login.php?error=unknownerror');
            exit();
        } else if ($validation) {
            header('Location: ../index.php?success=login');
            exit();
        }
    }

} else {
    header("Location: ../login.php");
}