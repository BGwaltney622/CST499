<?php
if (isset($_POST['picture-submit'])) {
    require_once 'config.php';
    require_once '../classes/student.php';
    $currentDirectory = getcwd();
    $uploadDirectory = "/../uploads/";

    // These will be the only file extensions allowed 
    $fileExtensionsAllowed = ['jpeg','jpg','png']; 

    //sets some variables about the file & extracts the extension for validation
    $fileName = $_FILES['customFile']['name'];
    $fileSize = $_FILES['customFile']['size'];
    $fileTmpName  = $_FILES['customFile']['tmp_name'];
    $fileType = $_FILES['customFile']['type'];
    $fileExtension = explode('.',$fileName);
    $fileExtension = strtolower(end($fileExtension));

    //sets the path for upload
    $uploadPath = $currentDirectory . $uploadDirectory . basename($fileName); 

    //Validation
    if (!in_array($fileExtension,$fileExtensionsAllowed)) {
        header("Location: ../profile.php?error=badfiletype");
        exit();
    }

    if ($fileSize > 4000000) {
        header("Location: ../profile.php?error=filetolarge");
        exit();
    }

    //Saves the file
    $didUpload = move_uploaded_file($fileTmpName, $uploadPath);

    //Updates DB
    if ($didUpload) {
        $fileLocation = "uploads/" . str_replace(' ', '', $fileName);
        Student::updatePicture($fileLocation, $_SESSION['studentId']);
        header("Location: ../profile.php?success=fileuploaded");
    } else {
        header("Location: ../profile.php?error=unknownerror");
        exit();
    }


} else {
    header("Location: ../profile.php");
}