<?php
if (isset($_POST['add-course'])) {
    require('../classes/course.php');

    //Form Validation
    if (empty($_POST['name']) || empty($_POST['semester']) || empty($_POST['maxenrollments']) || empty($_POST['description'])) {
        header('Location: ../addcourse.php?error=emptyfields');
        exit();
    }
   
    //Creates Course Object
    $course = new Course(null,
                    $_POST['name'], 
                    $_POST['semester'],
                    $_POST['description'], 
                    $_POST['maxenrollments']
                    );

    $course->submitCourse();
    header("Location: ../addcourse.php?success=courseadded");
} else {
    header("Location: ../login.php");
}