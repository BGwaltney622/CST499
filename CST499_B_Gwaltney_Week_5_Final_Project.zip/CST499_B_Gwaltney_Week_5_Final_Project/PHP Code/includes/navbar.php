<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="navbar-brand" href="#">
        <img src=".\public\course_registration.jpg" width="30" height="30" alt="">
    </div>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup"
        aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav mr-auto">
            <a class="nav-item nav-link <?php echo (($CURRENT_PAGE == "Home") ? 'active' : '')?>"
                href="./index.php">Home</a>
            <?php
            if (isset($_SESSION['admin']) &&  $_SESSION['admin'] == 1) {
              echo '<a class="nav-item nav-link '.(($CURRENT_PAGE == "Courses") ? 'active' : '').'" href="./courses.php">View Courses</a>
                    <a class="nav-item nav-link '.(($CURRENT_PAGE == "AddCourse") ? 'active' : '').'" href="./addcourse.php">Add Course</a>';
            } else {
              echo ''.isset($_SESSION['studentId']) ? '<a class="nav-item nav-link '.(($CURRENT_PAGE == "Courses") ? 'active' : '').'" href="./courses.php">Course Registration</a>' : ''.'
              <a class="nav-item nav-link '. (($CURRENT_PAGE == "ContactUs") ? 'active' : '').'" href="./contact.php">Contact Us</a>';
            }
            ?>
        </div>
        <?php
        if (isset($_SESSION['studentId'])) {
          echo '<div class="navbar-nav">
                  <a class="nav-item nav-link '.(($CURRENT_PAGE == "Profile") ? 'active' :'').'" href="./profile.php">Profile</a>
                  <a class="nav-item nav-link" href="./includes/logout.php">Logout</a>
              </div>';      
        } else {
          echo  '<div class="navbar-nav">
                  <a class="nav-item nav-link '.(($CURRENT_PAGE == "Login") ? 'active' : '').'" href="./login.php">Login</a>
                  <a class="nav-item nav-link '.(($CURRENT_PAGE == "Registration") ? 'active' : '').'" href="./registration.php">Registration</a>
                </div>';
        }
        ?>
    </div>
</nav>