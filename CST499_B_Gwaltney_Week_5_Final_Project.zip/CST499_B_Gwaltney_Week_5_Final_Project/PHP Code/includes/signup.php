<?php
//Validates script was entered from submit button on registration form
if (isset($_POST['submit-signup'])) {
    require('../classes/student.php');

    //Form Validation
    if (empty($_POST['email']) || empty($_POST['password']) || empty($_POST['password-reenter']) || empty($_POST['firstName']) || empty($_POST['lastName']) || empty($_POST['phone'])) {
        header('Location: ../registration.php?error=emptyfields');
        exit();
    } elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        header('Location: ../registration.php?error=invalidemail');
        exit();
    } elseif ($_POST['password'] !== $_POST['password-reenter']) {
        header('Location: ../registration.php?error=passwordmatch');
        exit();
    }
   
    //Creates Student Object
    $student = new Student(null,
                    $_POST['email'], 
                    password_hash($_POST['password'], PASSWORD_DEFAULT), 
                    $_POST['firstName'],
                    $_POST['lastName'], 
                    $_POST['phone'],
                    null,
                    null);

    //Validates email and submits if unique
    if ($student->uniqueEmail()) {
        $student->submitStudent();
    } else {
        header('Location: ../registration.php?error=uniqueemail');
        exit();
    }

    header("Location: ../login.php?success=accountcreated");
} else {
    header("Location: ../registration.php");
}