<?php
require '../classes/course.php';

if (isset($_POST['filter'])) {
    $valid_semesters = ['Spring', 'Summer', 'Fall'];
    $show_semesters = [];
    foreach ($_POST as $key => $value) {
        if (in_array($key, $valid_semesters)) {
            array_push($show_semesters, $key);
        }
    }

    if (count($show_semesters) == 0) {
        header('Location: ../courses.php');
    } else {
        header('Location: ../courses.php?filter='.implode(",", $show_semesters));
    }
    
    
}