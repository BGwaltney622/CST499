<?php

//Validates script was entered from submit button on login form
if (isset($_POST['update'])) {

    require('../classes/student.php');
    session_start();

    //Pulls and creates student
    $student = Student::getStudent($_SESSION['studentId']);    

    //Validates for fields and email
    if (empty($_POST['firstName']) || empty($_POST['lastName']) || empty($_POST['email']) || empty($_POST['phone'])) {
        header('Location: ../profile.php?error=emptyfields');
        exit();
    } elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        header('Location: ../profile.php?error=invalidemail');
        exit();
    } else {
        //Update student
        $student->setFirstName($_POST['firstName']);
        $student->setlastName($_POST['lastName']);
        $student->setEmail($_POST['email']);
        $student->setPhone($_POST['phone']);


        $student->updateStudent();

        header("Location: ../profile.php?success=updated");
    }

} else {
    header("Location: ../index.php");
}