<?php require("includes/config.php");?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php require("includes/head.php");?>
</head>
<body>
    <?php require("includes/navbar.php");?>
    <h1>Contact</h1>
</body>
<?php require("includes/scripts.php")?>
</html>