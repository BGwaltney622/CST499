<?php
require_once 'database.php';

class Course extends Database {
    private $id = null;
    private $courseName;
    private $courseSemester;
    private $courseDescription;
    private $maxEnrollments;

    public function __construct($id, $courseName, $courseSemester, $courseDescription, $maxEnrollments) {
        $this->id = $id;
        $this->courseName = $courseName;
        $this->courseSemester = $courseSemester;
        $this->courseDescription = $courseDescription;
        $this->maxEnrollments = $maxEnrollments;
    }

    public function submitCourse() {
        $sql = "INSERT INTO tblcourse(courseName, courseSemester, courseDescription,maxEnrollments) VALUES (?, ?, ?, ?);";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$this->courseName, $this->courseSemester, $this->courseDescription, $this->maxEnrollments]);
        $stmt = null;
    }

    public function deleteCourse() {
        $sql = "DELETE FROM tblcourse WHERE id = ?;";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$this->id]);
        $stmt = null;
    }

    public static function getCourses() {
        $sql = "SELECT * FROM tblcourse;";
        $dbconn = new Database();
        $stmt = $dbconn->connect()->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE, "Course", [0,0,0,0,0]);
        $stmt = null;
        return $result;
    }

    public static function getCourse($id) {
        $sql = "SELECT * FROM tblcourse WHERE id = ?;";
        $dbconn = new Database();
        $stmt = $dbconn->connect()->prepare($sql);
        $stmt->execute([$id]);
        $stmt->setFetchMode(PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE, "Course", [0,0,0,0,0]);
        $result = $stmt->fetch();
        $stmt = null;
        return $result;
    }

    public static function getCourseBySemester($sql, $semesters) {
        $dbconn = new Database();
        $stmt = $dbconn->connect()->prepare($sql);
        $stmt->execute($semesters);
        $result = $stmt->fetchAll(PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE, "Course", [0,0,0,0,0]);
        $stmt = null;
        return $result;
    }

    //Getters
    public function getCourseId() {return $this->id;}
    public function getCourseName() {return $this->courseName;}
    public function getCourseSemester() {return $this->courseSemester;}
    public function getCourseDescription() {return $this->courseDescription;}
    public function getMaxEnrollments() {return $this->maxEnrollments;}
}