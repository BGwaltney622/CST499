<?php
require_once __DIR__ . '/../protected/config.php';

class Database {

    private $dbServername = DBSERVERNAME;
    private $dbUsername = DBUSERNAME;
    private $dbPassword = DBPASSWORD;
    private $dbName = DBNAME;

    //creates connection to the database
    protected function connect() {
        $dsn = 'mysql:host=' . $this->dbServername . ';dbname=' . $this->dbName;
        try {
            $conn = new PDO($dsn, $this->dbUsername, $this->dbPassword);
            $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $conn;
        } catch (PDOException $e) {
            echo "Could not connect to database: " . $e->getMessage();
        }    
    }
}