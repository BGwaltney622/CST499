<?php
require_once 'database.php';

class CourseRegistrations extends Database {

    public static function getRegistrationsByCourse($id) {
        $sql = "SELECT COUNT(*) FROM tblregistrations WHERE courseId = ?;";
        $dbconn = new Database();
        $stmt = $dbconn->connect()->prepare($sql);
        $stmt->execute([$id]);
        $result = $stmt->fetch();
        $stmt = null;
        return $result;
    }

    public static function getRegistrationsByStudent($id) {
        $sql = "SELECT * FROM tblregistrations WHERE studentId = ?;";
        $dbconn = new Database();
        $stmt = $dbconn->connect()->prepare($sql);
        $stmt->execute([$id]);
        $result = $stmt->fetchAll();
        $stmt = null;
        return $result;
    }

    public static function validateEnrollment($courseId, $studentId, $courseRegistrations) {
        foreach ($courseRegistrations as $registration) {
            if ($studentId == $registration['studentId']) {
                if ($courseId == $registration['courseId']) {
                    return true;
                }
            } else {
                return false;
            }
        }
    }

    public static function register($courseId, $studentId) {
        $sql = "INSERT INTO tblregistrations(studentId, courseId) VALUES (?, ?);";
        $dbconn = new Database();
        $stmt = $dbconn->connect()->prepare($sql);
        $stmt->execute([$studentId, $courseId]);
        $stmt = null;
    }

    public static function cancelEnrollment($courseId, $studentId) {
        $sql = "DELETE FROM tblregistrations WHERE studentId = ? AND courseId = ?;";
        $dbconn = new Database();
        $stmt = $dbconn->connect()->prepare($sql);
        $stmt->execute([$studentId, $courseId]);
        $stmt = null;
        $return = CourseRegistrations::pullWaitlist($courseId);
        print_r($return);
        if (array_key_exists('MIN(id)', $return) && is_null($return['MIN(id)'])) {
            return;
        } else {
            CourseRegistrations::promoteWaitlist($return['MIN(id)']);
        }
    }

    public static function pullWaitlist($courseId) {
        $sql = "SELECT MIN(id) FROM tblwaitlist WHERE courseId = ?;";
        $dbconn = new Database();
        $stmt = $dbconn->connect()->prepare($sql);
        $stmt->execute([$courseId]);
        $result = $stmt->fetch();
        $stmt = null;
        return $result; 
    }

    public static function promoteWaitlist($waitlistId) {
        $sql = "SELECT studentId, courseId FROM tblwaitlist WHERE id = ?;";
        $dbconn = new Database();
        $stmt = $dbconn->connect()->prepare($sql);
        $stmt->execute([$waitlistId]);
        $result = $stmt->fetch();
        $stmt = null;
        CourseRegistrations::register($result['courseId'], $result['studentId']); 
        CourseRegistrations::removeWaitlist($result['courseId'], $result['studentId']); 
        return;
    }

    public static function waitlist($courseId, $studentId){
        $sql = "INSERT INTO tblwaitlist(studentId, courseId) VALUES (?, ?);";
        $dbconn = new Database();
        $stmt = $dbconn->connect()->prepare($sql);
        $stmt->execute([$studentId, $courseId]);
        $stmt = null;
    }

    public static function getWaitlistsByStudent($id) {
        $sql = "SELECT * FROM tblwaitlist WHERE studentId = ?;";
        $dbconn = new Database();
        $stmt = $dbconn->connect()->prepare($sql);
        $stmt->execute([$id]);
        $result = $stmt->fetchAll();
        $stmt = null;
        return $result;
    }

    public static function removeWaitlist($courseId, $studentId) {
        $sql = "DELETE FROM tblwaitlist WHERE studentId = ? AND courseId = ?;";
        $dbconn = new Database();
        $stmt = $dbconn->connect()->prepare($sql);
        $stmt->execute([$studentId, $courseId]);
        $stmt = null;
    }

    public static function waitlistStatus($courseId, $studentId){
        $sql = "SELECT COUNT(*) FROM tblwaitlist WHERE studentId = ? AND courseId = ?;";
        $dbconn = new Database();
        $stmt = $dbconn->connect()->prepare($sql);
        $stmt->execute([$studentId, $courseId]);
        $result = $stmt->fetch();
        $stmt = null;
        return $result;
    }
}