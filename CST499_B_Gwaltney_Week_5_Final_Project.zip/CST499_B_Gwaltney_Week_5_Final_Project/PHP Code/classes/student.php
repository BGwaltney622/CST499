<?php
require_once 'database.php';

class Student extends Database {

    private $id = null;
    private $email;
    private $password;
    private $firstName;
    private $lastName;
    private $phone;
    private $picture = null;
    private $admin = null;

    public function __construct($id, $email, $password, $firstName, $lastName, $phone, $picture, $admin) {
        $this->id = $id;
        $this->email = $email;
        $this->password = $password;
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->phone = $phone;
        $this->picture = $picture;
        $this->admin = $admin;

    }

    //Validates Student with same email doesn't exist
    public function uniqueEmail() {
        $sql = "SELECT email FROM tblstudent WHERE email = ?;";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$this->email]);
        $result = $stmt->fetch();
        if (!$result) {
            return true;
        }
        $stmt = null;
    }

    //Adds Student to DB
    public function submitStudent() {
        $sql = "INSERT INTO tblstudent(email, password, firstName, lastName, phone) VALUES (?, ?, ?, ?, ?);";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$this->email, $this->password, $this->firstName, $this->lastName, $this->phone]);
        $stmt = null;
    }

    //Update Student
    public function updateStudent() {
        $sql = "UPDATE tblstudent SET email = ?, firstName = ?, lastName = ?, phone = ? WHERE id = ?;";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$this->email, $this->firstName, $this->lastName, $this->phone, $this->id]);
        $stmt = null;
        $_SESSION['firstName'] = $this->firstName;
    }

    //Gets Student from database and returns as object
    public static function getStudent($id) {
        $sql = "SELECT * FROM tblstudent WHERE id = ?;";
        $dbconn = new Database();
        $stmt = $dbconn->connect()->prepare($sql);
        $stmt->execute([$id]);
        $result = $stmt->fetch();
        $stmt = null;

        if ($result) {
            $student = new Student($result['id'],
                             $result['email'], 
                             $result['password'],
                             $result['firstName'],
                             $result['lastName'], 
                             $result['phone'], 
                             $result['picture'],
                             $result['admin']);
            return $student;
        } else {
            return null;
        }
        
    }  

    // Validates Student login 
    public static function validateLogin($email, $password) {
        $sql = "SELECT * FROM tblstudent WHERE email = ?;";
        $dbconn = new Database();
        $stmt = $dbconn->connect()->prepare($sql);
        $stmt->execute([$email]);
        $result = $stmt->fetch();
        $stmt = null;

        if ($result) {
            $passwordCheck = password_verify($password, $result['password']);
            if (!$passwordCheck) {
                return 'wrong password';
            }else if ($passwordCheck) {
                Student::loginStudent($result);
                return true;
            } else {
                return 'unknown error';
            }
        } else if (!$result) {
            return 'no student';
        }
    }

    //Logs the student in
    private static function loginStudent($studentResult) {
        session_start();
        $_SESSION['studentId'] = $studentResult['id'];
        $_SESSION['firstName'] = $studentResult['firstName'];
        $_SESSION['admin'] = $studentResult['admin'];
    }

    //Handles the update of the profiel picture
    public static function updatePicture ($fileName, $id) {
        $sql = "UPDATE tblstudent SET picture = ? WHERE id = ?;";
        $dbconn = new Database();
        $stmt = $dbconn->connect()->prepare($sql);
        $stmt->execute([$fileName, $id]);
        $stmt = null; 
    }

    //Getters
    public function getId() {return $this->id;}
    public function getEmail() {return $this->email;}
    public function getFirstName() {return $this->firstName;}
    public function getLastName() {return $this->lastName;}
    public function getPhone() {return $this->phone;}
    public function getPicture() {return $this->picture;}

    //Setters
    public function setFirstName($firstName){$this->firstName = $firstName;}
    public function setLastName($lastName){$this->lastName = $lastName;}
    public function setEmail($email){$this->email = $email;}
    public function setPhone($phone){$this->phone = $phone;}
}