<?php require("includes/config.php");?>
<?php 
    require 'classes/course.php';
    require 'classes/student.php';
    require 'classes/course_registrations.php';
?>
<?php
    if (!isset($_SESSION['studentId'])) {
        header('Location: login.php');
    }

    $student = Student::getStudent($_SESSION['studentId']);
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <?php require("includes/head.php");?>
    </head>

    <body>
        <?php require("includes/navbar.php");?>
        <?php
        if (!isset($_GET['filter'])){
            $courses = Course::getCourses();
        }
        if (isset($_GET['filter'])) {
            $list = explode(",", $_GET['filter']);
            if (count($list) == 1) {
                $sql = "SELECT * FROM tblcourse WHERE courseSemester = ?;";
                $courses = Course::getCourseBySemester($sql, $list);
            } else if (count($list) == 2) {
                $sql = "SELECT * FROM tblcourse WHERE courseSemester IN(?, ?);";
                $courses = Course::getCourseBySemester($sql, $list);
            } else {
                $sql = "SELECT * FROM tblcourse WHERE courseSemester IN(?, ?, ?);";
                $courses = Course::getCourseBySemester($sql, $list);
            }
        }
        if (isset($_GET['success'])) {
            switch ($_GET['success']){
                case 'enrolled':
                    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Enrolled in Course!</strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>';
                    break;
                case 'waitlist':
                    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Added to Waitlist!</strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>';
                break;
                case 'waitlistremoved':
                    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Removed from Waitlist!</strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>';
                break;
                case 'enrollmentremoved':
                    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Removed from Course!</strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>';
                break;
                case 'coursedelete':
                    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Course Delete!</strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>';
                break;
            }
        }
        if (isset($_GET['error'])) {
            switch ($_GET['error']){
                case 'enrolled':
                    echo '<div class="alert alert-danger" role="alert">You are already enrolled in this course!
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>';
                break;
                case 'noitem':
                    echo '<div class="alert alert-danger" role="alert">You must select a semester to filter by
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>';
                break;
            }
        }
        ?>
        <form action="includes/filter.php" method="post">
            <h5 style="padding: 0.5em 2em;">Filter by Semester</h5>
            <div class="grid-filter">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                            <input type="checkbox" name="Spring" aria-label="Checkbox for following text input">
                        </div>
                    </div>
                    <input type="text" class="form-control" placeholder="Spring" aria-label="Text input with checkbox">
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                            <input type="checkbox" name="Summer" aria-label="Checkbox for following text input">
                        </div>
                    </div>
                    <input type="text" class="form-control" placeholder="Summer" aria-label="Text input with checkbox">
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                            <input type="checkbox" name="Fall" aria-label="Checkbox for following text input">
                        </div>
                    </div>
                    <input type="text" class="form-control" placeholder="Fall" aria-label="Text input with checkbox">
                </div>
            </div>
            <button style="margin: 0.5em 2em;" type="submit" name="filter" class="btn btn-primary btn-sm">Filter</button>
        </form>
        <div class="grid-container">
            <?php
                $studentEnrollments = CourseRegistrations::getRegistrationsByStudent($_SESSION['studentId']);
                if (!isset($courses)||empty($courses)) {
                    echo '<h3> No Courses Found! </h3>';
                } else {
                    foreach ($courses as $course) {
                        if ($_SESSION['admin']) {
                            $status = "Remove Course";
                        } else if (CourseRegistrations::validateEnrollment($course->getCourseId(), $_SESSION['studentId'], $studentEnrollments)) {
                            $status = "Cancel Registration";
                        } else if (CourseRegistrations::waitlistStatus($course->getCourseId(), $_SESSION['studentId'])['COUNT(*)'] > 0) {
                            $status = "Cancel Waitlist";
                        } else if (($course->getMaxEnrollments() <= CourseRegistrations::getRegistrationsByCourse($course->getCourseId())['COUNT(*)'])) {
                            $status = "Waitlist";
                        }  else {
                            $status = "Register";
                        }
                        $color_dispatch = Array(
                            'Cancel Registration' => 'danger',
                            'Waitlist' => 'info',
                            'Cancel Waitlist' => 'warning',
                            'Register' => 'primary',
                            'Remove Course' => 'danger'
                        );
                        echo '<form action="includes/course_register.php?courseId='.$course->getCourseId().'" method="post">  
                                <div class="card">
                                <h5 class="card-header">'.$course->getCourseName().'</h5>
                                    <div class="card-body">
                                        <h5 class="card-title">'.$course->getCourseSemester().'</h5>
                                        <p class="card-text">'.$course->getCourseDescription().'</p>
                                        <p class="card-text">'.(intval($course->getMaxEnrollments()) - intval(CourseRegistrations::getRegistrationsByCourse($course->getCourseId())['COUNT(*)'])).' out of '.$course->getMaxEnrollments().' avalible</p>
                                        <button type="submit" name="'.$status.'" class="btn btn-'.$color_dispatch[$status].'">'.$status.'</button>
                                    </div>
                                </div>
                            </form>';
                    }
                }
            ?>
        </div>
    </body>
    <?php require("includes/scripts.php");?>

</html>
