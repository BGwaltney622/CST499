<?php require("includes/config.php");?>
<?php require_once 'classes/student.php';?>

<?php
if (!isset($_SESSION['studentId']) || !$_SESSION['admin']) {
    header('Location: index.php');
}
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <?php require("includes/head.php");?>
    </head>

    <body>
        <?php require("includes/navbar.php");?>
        <div class="row">
            <div class="col-10 mx-auto">
                <div class="card card-signin my-5">
                    <div class="card-body">
                        <h5 class="card-title text-center">Add a Course</h5>
                        <?php
                    if (isset($_GET['error'])) {
                        switch ($_GET['error']){
                            case 'emptyfields':
                                echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <strong>All Fields Must be Completed!</strong>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>';
                                break;
                        }
                    }
                    if (isset($_GET['success'])) {
                        switch ($_GET['success']){
                            case 'courseadded':
                                echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <strong>Course Added!!!</strong>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>';
                                break;
                        }
                    }
                    ?>
                        <form action="includes/add_course.php" method="post">
                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label for="name">Course Name</label>
                                    <input type="text" class="form-control" name="name" placeholder="Course Name">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="semester">Semester</label>
                                    <select class="form-control" name="semester">
                                        <option>Spring</option>
                                        <option>Summer</option>
                                        <option>Fall</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="maxenrollments">Maximum Enrollments</label>
                                    <input type="text" class="form-control" name="maxenrollments"
                                        placeholder="Maximum Enrollments">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="description">Course Description</label>
                                <textarea class="form-control" name="description" rows="3" placeholder="Course Description"></textarea>
                            </div>
                            <div class="text-center">
                                <br>
                                <button type="submit" name="add-course"
                                    class="btn btn-lg btn-primary text-uppercase">Add Course</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </body>
    <?php require("includes/scripts.php")?>

</html>