<?php require("includes/config.php");?>
<?php
if (isset($_SESSION['studentId'])) {
    header('Location: index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php require("includes/head.php");?>
</head>
<body>
    <?php require("includes/navbar.php");?>
    <div class="container">
        <?php
        if (isset($_GET['success'])) {
            switch ($_GET['success']){
                case 'accountcreated':
                    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Account Created!</strong> You can now login.
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>';
                    break;
            }
        }
        if (isset($_GET['error'])) {
            switch ($_GET['error']){
                case 'nostudentfound':
                    echo '<div class="alert alert-danger" role="alert">Email not found!</div>';
                    break;
                case 'wrongpassword':
                    echo '<div class="alert alert-danger" role="alert">Incorrect Password!</div>';
                    break;
                case 'unknownerror':
                    echo '<div class="alert alert-danger" role="alert">An Unknown Error Occured, Try Again!</div>';
                    break;
            }
        }
        ?>
        <div class="row">
            <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
                <div class="card my-5">
                    <div class="card-body">
                        <h5 class="card-title text-center">Sign In</h5>
                        <form action="includes/login_script.php" method="post">
                            <div class="form-label">
                                <label for="inputEmail">Email address</label>
                                <input type="email" name="email" class="form-control" placeholder="Email address" required autofocus>
                                <br>
                            </div>
                            <div class="form-label">
                                <label for="inputPassword">Password</label>
                                <input type="password" name="password" class="form-control" placeholder="Password" required>
                                <br>
                            </div>
                            <button class="btn btn-lg btn-primary btn-block text-uppercase" name="sign-in" type="submit">Sign in</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<?php require("includes/scripts.php")?>
</html>