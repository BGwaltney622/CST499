-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2021 at 10:53 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cst499`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblcourse`
--

CREATE TABLE `tblcourse` (
  `id` int(255) NOT NULL,
  `courseName` varchar(256) DEFAULT NULL,
  `courseSemester` varchar(256) DEFAULT NULL,
  `courseDescription` text DEFAULT NULL,
  `maxEnrollments` int(11) DEFAULT 24
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblregistrations`
--

CREATE TABLE `tblregistrations` (
  `id` int(255) NOT NULL,
  `studentId` int(255) DEFAULT NULL,
  `courseId` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblstudent`
--

CREATE TABLE `tblstudent` (
  `id` int(255) NOT NULL,
  `firstName` varchar(50) DEFAULT NULL,
  `lastName` varchar(50) DEFAULT NULL,
  `email` varchar(256) DEFAULT NULL,
  `password` varchar(512) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `picture` varchar(512) DEFAULT 'http://ssl.gstatic.com/accounts/ui/avatar_2x.png',
  `admin` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblstudent`
--

INSERT INTO `tblstudent` (`id`, `firstName`, `lastName`, `email`, `password`, `phone`, `picture`, `admin`) VALUES
(1, 'Admin', 'Admin', 'admin@email.com', '$2y$10$3vFLIzoRUa43gN.AmOEleua9gckxmffbG5eBBu0fxPwob3e5Zk2EW', '123-456-7890', 'http://ssl.gstatic.com/accounts/ui/avatar_2x.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblwaitlist`
--

CREATE TABLE `tblwaitlist` (
  `id` int(255) NOT NULL,
  `studentId` int(255) DEFAULT NULL,
  `courseId` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblcourse`
--
ALTER TABLE `tblcourse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblregistrations`
--
ALTER TABLE `tblregistrations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `studentId` (`studentId`),
  ADD KEY `courseId` (`courseId`);

--
-- Indexes for table `tblstudent`
--
ALTER TABLE `tblstudent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblwaitlist`
--
ALTER TABLE `tblwaitlist`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Course Id` (`courseId`),
  ADD KEY `Student Id` (`studentId`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblregistrations`
--
ALTER TABLE `tblregistrations`
  ADD CONSTRAINT `courseId` FOREIGN KEY (`courseId`) REFERENCES `tblcourse` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `studentId` FOREIGN KEY (`studentId`) REFERENCES `tblstudent` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tblwaitlist`
--
ALTER TABLE `tblwaitlist`
  ADD CONSTRAINT `Course Id` FOREIGN KEY (`courseId`) REFERENCES `tblcourse` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `Student Id` FOREIGN KEY (`studentId`) REFERENCES `tblstudent` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
