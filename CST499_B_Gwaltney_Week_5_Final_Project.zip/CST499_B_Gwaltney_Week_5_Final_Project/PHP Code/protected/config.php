<?php 
//Config DB Info
define('DBSERVERNAME', 'localhost'); 
define('DBUSERNAME', 'root'); 
define('DBPASSWORD', ''); 
define('DBNAME', 'cst499'); 